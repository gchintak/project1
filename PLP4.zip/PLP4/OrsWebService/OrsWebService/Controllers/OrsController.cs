﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OrsWebService.Models;


namespace OrsWebService.Controllers
{
    [RoutePrefix("api/Ors")]
    public class OrsController : ApiController
    {
        OrsEntities db = new OrsEntities();

        [HttpPost]
        [Route("JobAppliedEntry")]
        public IHttpActionResult JobAppliedEntry(int jobid,int jobseekerid,string status)
        {
            try
            {
                OrsEntities entities = new OrsEntities();
                entities.JobsAppliedInfoNews.Add(new JobsAppliedInfoNew()
                {
                    JobId = jobid,
                    JobSeekerId = jobseekerid,
                    Status = status
                });
                entities.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            return Ok();

        }
        [HttpPost]
        [Route("RegisterJobSeeker")]
        public IHttpActionResult RegisterJobSeeker(JobSeekerPersInfo seeker)
        {
            try
            {
                OrsEntities entities = new OrsEntities();
                entities.JobSeekerPersInfoes.Add(new JobSeekerPersInfo()
                {
                    FirstName = seeker.FirstName,
                    LastName = seeker.LastName,
                    DOB = seeker.DOB,
                    EmailId = seeker.EmailId,
                    MobileNo = seeker.MobileNo,
                    Gender = seeker.Gender,
                    Address1 = seeker.Address1,
                    City = seeker.City,

                    State1 = seeker.State1,
                    UserName = seeker.UserName,
                    Pwd = seeker.Pwd

                });
                entities.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            return Ok();
        }

        [HttpPost]
        [Route("RegisterEmployer")]
        public IHttpActionResult RegisterEmployer(EmployerInfo employer)
        {
            try
            {
                OrsEntities entities = new OrsEntities();
                entities.EmployerInfoes.Add(new EmployerInfo()
                {
                    CompanyName = employer.CompanyName,
                    EmailId = employer.EmailId,
                    MobileNo = employer.MobileNo,
                    ContactPerson = employer.ContactPerson,
                    Website = employer.Website,
                    Address1 = employer.Address1,
                    City = employer.City,
                    State1 = employer.State1,
                    UserName = employer.UserName,
                    Pwd = employer.Pwd
                });
                entities.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            return Ok();

        }

        [HttpPost]
        [Route("EducationalDetails")]
        public IHttpActionResult EducationalDetails(JobSeekerEducInfo eduinfo)
        {
            SqlConnection conn = new SqlConnection("data source = NDAMSSQL\\SQLILEARN; initial catalog = Training_13Aug19_Pune; user id = sqluser; password = sqluser");
            SqlCommand cmd;
            SqlDataReader dr;
            string query = "Select Max(JobSeekerId) from ORS.JobSeekerPersInfo";
            cmd= new SqlCommand(query,conn);
            conn.Open();
            int id = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            

            try
            {
                OrsEntities entities = new OrsEntities();
                entities.JobSeekerEducInfoes.Add(new JobSeekerEducInfo()
                {
                    JobSeekerId = id,
                    InstituteName = eduinfo.InstituteName,
                    MaxQualification = eduinfo.MaxQualification,
                    PassingYear = eduinfo.PassingYear,
                    SSCPercent = eduinfo.SSCPercent,
                    HSCPercent = eduinfo.HSCPercent,
                    GraduationPercent = eduinfo.GraduationPercent,
                    Skills = eduinfo.Skills,
                    ProjectTitle = eduinfo.ProjectTitle,
                    WorkExperience = eduinfo.WorkExperience

                });
                entities.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            return Ok();

        } 
        [HttpGet]
        [Route("LoginJobSeeker")]
        public JobSeekerLogin LoginJobSeeker(string username,string password)
        {
            SqlConnection conn = new SqlConnection("data source = NDAMSSQL\\SQLILEARN; initial catalog = Training_13Aug19_Pune; user id = sqluser; password = sqluser");
            SqlCommand cmd;
            SqlDataReader dr;

            JobSeekerLogin seekerLoggedin = new JobSeekerLogin();
            try
            {
                cmd = new SqlCommand("ORS.LoginVerify", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                conn.Open();
                dr = cmd.ExecuteReader();
                if(!dr.Read())
                
                    return null;

                    seekerLoggedin.JobSeekerId = (int)dr[0];
                    seekerLoggedin.FirstName = (string)dr[1];
                    seekerLoggedin.LastName = (string)dr[2];
                    seekerLoggedin.InstituteName = (string)dr[3];
                    seekerLoggedin.MaxQualification = (string)dr[4];
                    seekerLoggedin.GraduationPercent = (double)dr[5];
                    seekerLoggedin.PassingYear = (DateTime)dr[6];
                    seekerLoggedin.HSCPercent = (double)dr[7];
                    seekerLoggedin.SSCPercent = (double)dr[8];
                    seekerLoggedin.ProjectTitle = (string)dr[9];
                    seekerLoggedin.Skills = (string)dr[10];
                    seekerLoggedin.WorkExperience = (int)dr[11];

                
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return seekerLoggedin;
        }

        [HttpGet]
        [Route("LoginEmployer")]
        public EmployerInfo LoginEmployer(string username, string password)
        {
            SqlConnection conn = new SqlConnection("data source = NDAMSSQL\\SQLILEARN; initial catalog = Training_13Aug19_Pune; user id = sqluser; password = sqluser");
            SqlCommand cmd;
            SqlDataReader dr;
            EmployerInfo info = new EmployerInfo();
            try
            {
                cmd = new SqlCommand("ORS.EmployerLogin", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                conn.Open();
                dr = cmd.ExecuteReader();
                if (!dr.Read())
                    return null;
                info.EmployerId = (int)dr[0];
                info.CompanyName = (string)dr[1];
                info.EmailId = (string)dr[2];
                info.MobileNo = (string)dr[3];
                info.ContactPerson = (string)dr[4];
                info.Website = (string)dr[5];
                info.Address1 = (string)dr[6];
                info.City = (string)dr[7];
                info.State1 = (string)dr[8];
                info.UserName = (string)dr[9];
                info.Pwd = (string)dr[10];   
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return info;

        }

        //[HttpGet]
        //[Route("SearchPostedJob")]
        //public JobOpeningInfo SearchPostedJob(string designation)
        //{
        //    SqlConnection conn = new SqlConnection("Data Source=.;database = Abhijeet_Practice;Integrated Security = true");
        //    SqlCommand cmd;
        //    SqlDataReader dr;

        //    JobOpeningInfo openinginfo = new JobOpeningInfo();
        //    try
        //    {
        //        cmd = new SqlCommand("ORS.JobOpening", conn);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@role", designation);
        //        conn.Open();
        //        dr = cmd.ExecuteReader();
        //        if (!dr.Read())
        //            return null;
        //        openinginfo.JobId = (int)dr[0];
        //        openinginfo.EmployerId = (int)dr[1];
        //        openinginfo.JobCategory = (string)dr[2];
        //        openinginfo.JobLocation = (string)dr[3];
        //        openinginfo.RequiredSkills = (string)dr[4];
        //        openinginfo.Role1 = (string)dr[5];
        //        openinginfo.MinQualification = (string)dr[6];
        //        openinginfo.MaxAge = (int)dr[7];
        //        openinginfo.Salary = (long)dr[8];
        //        openinginfo.JobDescription = (string)dr[9];
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //    return openinginfo;
        //}

        [HttpGet]
        [Route("SearchPostedJob")]
        public List<JobOpening> SearchPostedJob(string designation) //Search for Job by Designation
        {
            SqlConnection conn = new SqlConnection("data source = NDAMSSQL\\SQLILEARN; initial catalog = Training_13Aug19_Pune; user id = sqluser; password = sqluser");
            SqlCommand cmd;
            SqlDataReader dr;
            List<JobOpening> JobList = new List<JobOpening>();

            try
            {
                cmd = new SqlCommand("ORS.JobOpening", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@role", designation);

                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                DataTable JobOpeningTable = new DataTable();

                JobOpeningTable.Load(reader);

                for (int i = 0; i < JobOpeningTable.Rows.Count; i++)
                {

                    JobOpening jobOpening = new JobOpening();

                    jobOpening.JobId = (int)JobOpeningTable.Rows[i][0];
                    jobOpening.EmployerId = (int)JobOpeningTable.Rows[i][1];
                    jobOpening.JobCategory = (string)JobOpeningTable.Rows[i][2];
                    jobOpening.JobLocation = (string)JobOpeningTable.Rows[i][3];
                    jobOpening.RequiredSkills = (string)JobOpeningTable.Rows[i][4];
                    jobOpening.Role1 = (string)JobOpeningTable.Rows[i][5];
                    jobOpening.MinQualification = (string)JobOpeningTable.Rows[i][6];
                    jobOpening.MaxAge = (int)JobOpeningTable.Rows[i][7];
                    jobOpening.Salary = (long)JobOpeningTable.Rows[i][8];
                    jobOpening.JobDescription = (string)JobOpeningTable.Rows[i][9];
                    jobOpening.CompanyName = (string)JobOpeningTable.Rows[i][10];
                    JobList.Add(jobOpening);
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return JobList;
        }

        [HttpGet]
        [Route("JobApplicantsList")]
        public List<JobSeekerLogin> JobApplicantsList(int employerid) //Search for Job by Designation
        {
            SqlConnection conn = new SqlConnection("data source = NDAMSSQL\\SQLILEARN; initial catalog = Training_13Aug19_Pune; user id = sqluser; password = sqluser");
            SqlCommand cmd;
            SqlDataReader dr;
            List<JobSeekerLogin> JobApplicantslist = new List<JobSeekerLogin>();

            try
            {
                cmd = new SqlCommand("ORS.JobApplicantsNew", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@EmployerId", employerid);

                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                DataTable JobOpeningTable = new DataTable();

                JobOpeningTable.Load(reader);

                for (int i = 0; i < JobOpeningTable.Rows.Count; i++)
                {

                    JobSeekerLogin applicant = new JobSeekerLogin();

                    applicant.FirstName = (string)JobOpeningTable.Rows[i][0];
                    applicant.LastName = (string)JobOpeningTable.Rows[i][1];
                    applicant.MaxQualification = (string)JobOpeningTable.Rows[i][2];
                    applicant.PassingYear = (DateTime)JobOpeningTable.Rows[i][3];
                    applicant.GraduationPercent = (double)JobOpeningTable.Rows[i][4];
                    applicant.Skills = (string)JobOpeningTable.Rows[i][5];
                    applicant.WorkExperience = (int)JobOpeningTable.Rows[i][6];
                    applicant.InstituteName = (string)JobOpeningTable.Rows[i][7];
                    JobApplicantslist.Add(applicant);
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return JobApplicantslist;
        }






    }
}
