﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineRecruitmentSystem.Models;

namespace OnlineRecruitmentSystem.Controllers
{
    public class JobOpeningInfoesController : Controller
    {
        private Training_13Aug19_PuneEntities2 db = new Training_13Aug19_PuneEntities2();

        // GET: JobOpeningInfoes
        public ActionResult Index()
        {
            var jobOpeningInfoes = db.JobOpeningInfoes.Include(j => j.EmployerInfo).Include(j => j.JobsAppliedInfo);
            return View(jobOpeningInfoes.ToList());
        }

        // GET: JobOpeningInfoes/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobOpeningInfo jobOpeningInfo = db.JobOpeningInfoes.Find(id);
            if (jobOpeningInfo == null)
            {
                return HttpNotFound();
            }
            return View(jobOpeningInfo);
        }

        // GET: JobOpeningInfoes/Create
        public ActionResult Create()
        {
            ViewBag.EmployerId = new SelectList(db.EmployerInfoes, "EmployerId", "CompanyName");
            ViewBag.JobId = new SelectList(db.JobsAppliedInfoes, "JobId", "Status");
            return View();
        }

        // POST: JobOpeningInfoes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "JobId,EmployerId,JobCategory,JobLocation,RequiredSkills,Role1,MinQualification,MaxAge,Salary,JobDescription")] JobOpeningInfo jobOpeningInfo)
        {
            if (ModelState.IsValid)
            {
                db.JobOpeningInfoes.Add(jobOpeningInfo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EmployerId = new SelectList(db.EmployerInfoes, "EmployerId", "CompanyName", jobOpeningInfo.EmployerId);
            ViewBag.JobId = new SelectList(db.JobsAppliedInfoes, "JobId", "Status", jobOpeningInfo.JobId);
            return View(jobOpeningInfo);
        }

        // GET: JobOpeningInfoes/Edit/5
        public ActionResult JobOpeningEdit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobOpeningInfo jobOpeningInfo = db.JobOpeningInfoes.Find(id);
            if (jobOpeningInfo == null)
            {
                return HttpNotFound();
            }
            //ViewBag.EmployerId = new SelectList(db.EmployerInfoes, "EmployerId", "CompanyName", jobOpeningInfo.EmployerId);
            //ViewBag.JobId = new SelectList(db.JobsAppliedInfoes, "JobId", "Status", jobOpeningInfo.JobId);
            return View(jobOpeningInfo);
        }

        // POST: JobOpeningInfoes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult JobOpeningEdit([Bind(Include = "JobId,EmployerId,JobCategory,JobLocation,RequiredSkills,Role1,MinQualification,MaxAge,Salary,JobDescription")] JobOpeningInfo jobOpeningInfo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(jobOpeningInfo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
           // ViewBag.EmployerId = new SelectList(db.EmployerInfoes, "EmployerId", "CompanyName", jobOpeningInfo.EmployerId);
            //ViewBag.JobId = new SelectList(db.JobsAppliedInfoes, "JobId", "Status", jobOpeningInfo.JobId);
            return View(jobOpeningInfo);
        }

        // GET: JobOpeningInfoes/Delete/5
        public ActionResult JobOpeningDelete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobOpeningInfo jobOpeningInfo = db.JobOpeningInfoes.Find(id);
            if (jobOpeningInfo == null)
            {
                return HttpNotFound();
            }
            return View(jobOpeningInfo);
        }

        // POST: JobOpeningInfoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult JobOpeningDeleteConfirmed(int id)
        {
            JobOpeningInfo jobOpeningInfo = db.JobOpeningInfoes.Find(id);
            db.JobOpeningInfoes.Remove(jobOpeningInfo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
