﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineRecruitmentSystem.Models
{
    public class JobOpening
    {
        public int JobId { get; set; }
        public Nullable<int> EmployerId { get; set; }
        public string JobCategory { get; set; }
        public string JobLocation { get; set; }
        public string RequiredSkills { get; set; }
        public string Role1 { get; set; }
        public string MinQualification { get; set; }
        public Nullable<int> MaxAge { get; set; }
        public Nullable<long> Salary { get; set; }
        public string JobDescription { get; set; }
        public string CompanyName { get; set; }
    }
}